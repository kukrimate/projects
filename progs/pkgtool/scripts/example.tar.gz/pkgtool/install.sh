#!/bin/bash

echo "I'm the install script."
